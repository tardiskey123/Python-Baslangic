import random


def isim_olustur() :
    ad = ["Ahmet", "Hasar", "Ali", "Cansu", "İnan", "Yasemin", "Aslı", "Akın", "Tuğçe", "Sevda", "Sami", "Yasin"]
    soy_ad = ["Şengül", "Şen", "Ertem", "Gül", "Kaya", "Dağ", "Saçan", "Öztürk", "Canbaz", "Güleşen", "İrdem", "Şirin"]
    return "{} {}".format(random.choice(ad), random.choice(soy_ad))


adet = int(input("Kaç tane oluşturulsun?\n"))
for x in range(adet):
    print(isim_olustur())
